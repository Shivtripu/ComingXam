package com.capgemini.ui;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import com.capgemini.bean.Trainer;
import com.capgemini.exception.InvalidRatingException;
import com.capgemini.service.FeedbackService;

@SuppressWarnings("unused")
public class Main {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		FeedbackService serref = new FeedbackService();
		Trainer trainer=null;
		while(true)
		{
			System.out.println("1 for add feedback details..\n 2 get Deatils based on ratting.. \n 3 for exit");
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1: System.out.print("Enter Trainer Name:");
			String name=sc.next();
			name+=sc.nextLine();
			System.out.print("Enter Course Name");
			String cname=sc.nextLine();
			System.out.print("Enter Start Date");
			String date=sc.nextLine();
			System.out.print("Enter End Date");
			String edate=sc.nextLine();
			System.out.print("Enter Rating");
			int rating=sc.nextInt();
			try {
			LocalDate startdate=LocalDate.parse(date);
			LocalDate enddate=LocalDate.parse(edate);
			trainer=new Trainer(name,cname,startdate,enddate,rating);
			serref.addFeedback(trainer);
			}
			catch(DateTimeParseException e)
			{
				String s="please provide date in yyyy-mm-dd format";
				System.out.println(s);
			}
			break;
			case 2: System.out.print("Enter Rating");
			int rating1=sc.nextInt();
			try {
			System.out.println(serref.getTrainerList(rating1));
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			break;
			case 3: System.exit(0);
			}
					
		}
}
	}