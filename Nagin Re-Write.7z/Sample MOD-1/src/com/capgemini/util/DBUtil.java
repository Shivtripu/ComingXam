package com.capgemini.util;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.bean.Trainer;

public class DBUtil 
{
 static HashMap<Integer,Trainer> feedbackList=new HashMap<>();
	
	static
{
		feedbackList.put(412,new Trainer("Smitha","Java",LocalDate.of(2000, 12, 03),LocalDate.of(2001, 12, 03),5));
		feedbackList.put(223,new Trainer("Smitha","Java",LocalDate.of(2000, 12, 03),LocalDate.of(2000, 12, 03),4));
		feedbackList.put(434,new Trainer("Smitha","Java",LocalDate.of(2000, 12, 03),LocalDate.of(2000, 12, 03),3));

}

	public static HashMap<Integer, Trainer> getFeedbackList() {
		return feedbackList;
	}

	public static void setFeedbackList(HashMap<Integer, Trainer> feedbackList) {
		DBUtil.feedbackList = feedbackList;
	}
	
}