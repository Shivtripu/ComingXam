package com.capgemini.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.HashMap;
import com.capgemini.bean.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.IFeedbackDAO;
import com.capgemini.exception.InvalidRatingException;
import com.capgemini.service.FeedbackService;

class TestMain {

	@org.junit.jupiter.api.Test
	void test1() {
		//fail("Not yet implemented");
		IFeedbackDAO daoref=new  FeedbackDAO();
		HashMap<Integer,Trainer> hm1=new HashMap<>();
		hm1.put(412,new Trainer("Smitha","Java"
				,LocalDate.of(2000, 12, 03),LocalDate.of(2001, 12, 03),5));
		try {
			assertEquals(hm1,daoref.getTrainerList(5));
		} catch (InvalidRatingException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	@org.junit.jupiter.api.Test
	void test2() {
		//fail("Not yet implemented");
		IFeedbackDAO daoref=new  FeedbackDAO();
		HashMap<Integer,Trainer> hm1=new HashMap<>();
		hm1.put(412,new Trainer("Smitha","Java"
				,LocalDate.of(2000, 12, 03),LocalDate.of(2001, 12, 03),5));
		try {
			assertEquals(hm1,daoref.getTrainerList(5));
		} catch (InvalidRatingException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
	@org.junit.jupiter.api.Test
	void test3() {
		//fail("Not yet implemented");
		FeedbackService serref = new FeedbackService();
		HashMap<Integer,Trainer> hm1=new HashMap<>();
		hm1.put(434,new Trainer("Smitha","Java"
				,LocalDate.of(2000, 12, 03),LocalDate.of(2000, 12, 03),3));
		try {
			assertEquals(hm1,serref.getTrainerList(3));
		} catch (InvalidRatingException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
}

