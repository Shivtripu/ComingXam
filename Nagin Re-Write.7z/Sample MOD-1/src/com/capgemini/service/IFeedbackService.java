package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.bean.Trainer;
import com.capgemini.exception.InvalidRatingException;

public interface IFeedbackService 
{
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList(int rating) throws InvalidRatingException;

	

}
