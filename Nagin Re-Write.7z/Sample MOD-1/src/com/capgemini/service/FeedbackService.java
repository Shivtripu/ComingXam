package com.capgemini.service;
import java.util.HashMap;

import com.capgemini.bean.Trainer;
import com.capgemini.dao.FeedbackDAO;
import com.capgemini.dao.IFeedbackDAO;
import com.capgemini.exception.InvalidRatingException;

public class FeedbackService implements IFeedbackService {
	 IFeedbackDAO daoref=new  FeedbackDAO();

	@Override
	public void addFeedback(Trainer trainer) {
		// TODO Auto-generated method stub
		 daoref.addFeedback(trainer);
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws InvalidRatingException {
		// TODO Auto-generated method stub
		return daoref.getTrainerList(rating);
	}

}
