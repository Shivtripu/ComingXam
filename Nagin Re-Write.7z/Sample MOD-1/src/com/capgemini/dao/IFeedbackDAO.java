package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.bean.Trainer;
import com.capgemini.exception.InvalidRatingException;

public interface IFeedbackDAO
{
	public void addFeedback(Trainer trainer);
	HashMap<Integer, Trainer> getTrainerList(int rating) throws InvalidRatingException;
	
	

}
