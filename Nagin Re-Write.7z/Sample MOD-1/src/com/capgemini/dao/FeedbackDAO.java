package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.bean.Trainer;
import com.capgemini.exception.InvalidRatingException;
import com.capgemini.util.DBUtil;

public class FeedbackDAO implements IFeedbackDAO {
	
	DBUtil util=null;
	HashMap<Integer, Trainer> obj;
	public FeedbackDAO()
	{
		util=new DBUtil();
	}

	@Override
	public void addFeedback(Trainer trainer) {
		int id = ((int)(Math.random() * 100000)) % 1000;
		obj=DBUtil.getFeedbackList();
		obj.put(id, trainer);
		DBUtil.setFeedbackList(obj);
	}


	@Override
	public HashMap<Integer, Trainer> getTrainerList(int rating) throws InvalidRatingException 
	{
		HashMap<Integer,Trainer> hm1=new HashMap<>();
		obj=DBUtil.getFeedbackList();
		for(Map.Entry<Integer, Trainer> entry : obj.entrySet())
		{
			
			if(entry.getValue().getRating()==rating)
			{
				hm1.put(entry.getKey(), entry.getValue());
			}
		}
		
		if(hm1.isEmpty())
		{
			throw new InvalidRatingException("given rating does not present in the system");
		}
		else
		{
			return hm1;
		}
	}
}
