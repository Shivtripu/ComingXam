package com.capgemini.exception;

public class InvalidRatingException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidRatingException(String string)
	{
		super(string);
	}
}
